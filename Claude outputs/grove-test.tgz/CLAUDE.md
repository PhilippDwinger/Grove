# Grove – Anleitung für Claude

Grove ist Paddys persönliche digitale Welt (Website, später auch App).
Gefühl: **Grove** (Ökosystem, Wald, Jahresringe) **+ Groove** (Jazz, Musik, Nachtleben). Warm, ruhig, nicht überladen.
Sprache: Deutsch, locker (du).

## 🚫 Wichtigste Regel: Paddys Code ist tabu

- **`scripts/`** (Frontend-JavaScript) und **`backend/`** (Server, Bridge, APIs) gehören Paddy.
  Dort **niemals** etwas anlegen, ändern, umbenennen oder löschen – auch nicht per Bash.
- In `index.html` (und in künftigen HTML-Seiten) gibt es eine **PADDY-ZONE** für seine `<script>`-Tags.
  Diesen Bereich nicht anfassen.
- Wenn du etwas an seinem Code bräuchtest: **frag Paddy**, ob er es ändern möchte. Mach Vorschläge, aber schreib es nicht selbst.

## Rollen

| Wer    | Was                                                      |
|--------|----------------------------------------------------------|
| Paddy  | Gesamte Logik: JavaScript, Backend, Bridge, Daten        |
| Claude | Design: HTML-Gerüst, CSS, Animationen, Bilder/Icons      |

## Arbeitsweise

1. **Nicht vorausarbeiten.** Paddy baut zuerst eine Funktion.
2. Er sagt, welche IDs/Klassen/Elemente sein Script nutzt (oder du liest sein Script – **nur lesen**).
3. Dann baust du HTML, CSS und Animationen drumherum – passend zu seinen Hooks.
4. Animationen **nur in CSS** (`design/css/animations.css`), kein JavaScript.
5. Paddy sieht alles live über die VS-Code-Erweiterung **Live Server**.

## Ordnerstruktur

```
Grove/
├── CLAUDE.md               diese Anleitung
├── README.md               Übersicht für Paddy
├── index.html              Startseite (aktuell leer, Paddy baut)  → Claude
├── design/                 alles Sichtbare               → Claude
│   ├── css/base.css          Farben, Schriften, Reset
│   ├── css/layout.css        Seitenaufbau
│   ├── css/animations.css    fest gewählte Animationen
│   ├── css/grove-animationen.css  Animations-Bibliothek .a01 – .a30
│   ├── css/katalog.css       nur Layout der Katalog-Seite
│   ├── ANIMATIONEN.md        Liste + HTML-Snippets aller 30 Animationen
│   ├── img/                  Logo, Icons, Favicon
│   └── beispiele/            Referenz-Entwürfe (Web, App, Icon)
├── scripts/                Paddys Frontend-JS            → TABU
└── backend/                Paddys Backend / Bridge       → TABU
```
Neue Seiten kommen als eigene `.html` ins Hauptverzeichnis (oder später `pages/`), neue Styles als eigene Datei in `design/css/`.

## Design-System (v0.2 – exakt nach dem Grove-Icon-Canvas „Lichtung“)

**Farben** (CSS-Variablen in `design/css/base.css`):
- Grund `--ground #1C1420`, tief `--ground-deep #160F19`, Karten `--surface #241A27`, hervorgehoben `--surface-hi #2A1F2C`
- Linien `--border #2E2231`, `--border-hi #3A2C3D`
- Amber `--amber #E3A15A` (Akzent/Logo), `--amber-light #F2C08A` (Hover/aktiv)
- Text `--text #EFE6D6`, `--text-soft #CDBFAE`, `--muted #A8957F`
- Helle Logo-Variante: Grund `#9A5520`, Zeichen `#F3EBDD`

**Schriften:** Fraunces (Überschriften, die „o“ in Grove kursiv in Amber), Instrument Sans (Fließtext).

**Logo** (`design/img/`): Jahresringe/Schallplatte mit Tonarm-Schnitt und Keimling in der Mitte. Kein Text.
- `grove-logo.svg` Zeichen (für Hintergrund #1C1420) · `grove-logo-klein.svg` vereinfacht für ≤ 32 px
- `grove-icon.svg` App-Icon dunkel · `grove-icon-hell.svg` App-Icon hell · `favicon.svg` Browser-Tab
- Das Logo nie drehen (der Keimling stünde Kopf) – es „atmet“ (`.logo-breathe`).

**Beispiele** (`design/beispiele/`): `icon.html`, `icon-groessen.html`, `web-heute.html`, `app-heute.html` – Referenz-Entwürfe für Look & Aufbau (Sidebar-Navigation: Heute, Projekte, Gespräche, Daten, Geräte, Hain). Inhalte sind Platzhalter. `test-v01.html` = erste Testseite.

**Signature-Animation:** Schriftzug „Grove“ klappt auf zu „Gr**oooooo**ve“, die Extra-o's wippen nacheinander im Takt und klappen wieder ein (`.groove`, 9-s-Zyklus).

**Weitere Elemente:** Equalizer (`.eq`), pulsierender Status-Punkt (`.status`), Karten (`.card`, `.card--featured`, `.card--empty`), dezentes Filmkorn, `prefers-reduced-motion` wird respektiert.

## Animations-Bibliothek (Nummern 01–30)

Paddy wählt Animationen **per Nummer** („nimm 08“, „16 auf die Bridge-Seite“).
1. Lies `design/ANIMATIONEN.md`: Name, Klasse, Einsatzidee und fertiges HTML-Snippet je Nummer. Live-Katalog: `design/beispiele/animationen-katalog.html`.
2. Im `<head>` in dieser Reihenfolge: `design/css/base.css` → `design/css/grove-animationen.css` → `design/css/animations.css` (Letztere respektiert „Animationen reduzieren“).
3. Snippet unverändert einfügen, nur Pfade relativ zur Seite anpassen.
4. Andere Größe/Farbe: eigene Klasse in einer Seiten-CSS (z. B. `.hero .a03 { width: 260px; height: 260px; }`) – `grove-animationen.css` selbst nicht umbauen.
5. 11, 12, 13, 22, 30 füllen ihren Container → der braucht `position: relative; overflow: hidden;` und eine Höhe.
6. Soll eine Animation auf Paddys Daten reagieren, schlag ihm eine Klasse vor, die *sein* Script setzt (z. B. `.is-connected`), und style nur diese.
7. Neue Animation = nächste Nummer (`.a31` …): ans Ende von `grove-animationen.css`, Karte in `design/beispiele/animationen-katalog.html`, Abschnitt in `design/ANIMATIONEN.md`.

## Projekte in Grove

- **Bridge** – das Herzstück: Alle Geräte, die im Web posten können, kommunizieren miteinander und geben sich gegenseitig Aufgaben.
- **SynaPort** – eigenes Projekt von Paddy (Beschreibung folgt).

## Hosting

- Code liegt auf GitHub (Konto `PhilippDwinger`, Repo `Grove`, **public** – jeder kann alles im Repo lesen).
- `CLAUDE.md` steht in `.gitignore` und existiert nur lokal. Nicht wieder ins Repo aufnehmen.
- Die README auf GitHub bleibt bewusst kurz (nur Titel + ein Satz). Keine internen Infos dort reinschreiben.
- Die Website läuft als **Static Site auf Render** (kostenlos). Jeder Push auf `main` geht automatisch live.
- Achtung: Alles im Repo wird als Website öffentlich ausgeliefert. Sobald `backend/` echten Code bekommt, wird es ein eigener Render-Dienst. Nie Passwörter oder Keys ins Repo (`.env` steht in `.gitignore`).
